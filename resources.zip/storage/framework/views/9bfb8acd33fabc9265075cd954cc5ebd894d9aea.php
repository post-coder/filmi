

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card bg-dark">
                <div class="card-header"><?php echo e(__('Modifica un film')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('movie.destroy', ['movie'=>$movie])); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        
                        Sei sicuro di voler eliminare il film <i><?php echo e($movie->title); ?></i>?

                        <div class="form-group row mb-0">
                          <div class="col-md-6 offset-md-4">
                              <button type="submit" class="btn btn-primary">
                                  <?php echo e(__('Elimina')); ?>

                              </button>
                          </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gabry\Lavoro\Web\Progetti\Filmi\filmi\resources\views/movie/delete.blade.php ENDPATH**/ ?>