

<?php $__env->startSection('content'); ?>
  <div class="container">
    <div id="header">
      <a id="addMovie" href="<?php echo e(route('movie.create')); ?>">
        Aggiungi
      </a>
    </div>

  </div>

  <div id="movies-index" class="container">
    <div class="h1">Lista dei film da vedere</div>

    <div id="movies-list" class="accordion accordion-flush">

      <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="accordion-item movie <?php if($movie->seen): ?> is-seen <?php endif; ?>">
          <h2 id="heading-<?php echo e($loop->index); ?>" class="title accordion-header" >
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-<?php echo e($loop->index); ?>" aria-expanded="true" aria-controls="collapse-<?php echo e($loop->index); ?>">
                <strong><?php echo e($movie->title); ?></strong>
            </button>
          </h2>
          <div id="collapse-<?php echo e($loop->index); ?>" class="inner-details collapse accordion-collapse collapse" aria-labelledby="heading-<?php echo e($loop->index); ?>" data-bs-parent="#movies-list">
            <div class="accordion-body">
              <div class="movie-details">
                <div class="why">
                  <small>Perchè guardarlo?<br></small>
                  <?php echo e($movie->why); ?>

                </div>
                <div class="description">
                  <small>Descrizione<br></small>
                  <?php echo e($movie->description); ?>

                </div>
  
                <div class="created-by">
                  <small>Suggerito da </small>
                  <?php echo e($movie->user->name); ?>

                </div>
              </div>

              <div class="movie-actions">
                <div class="movie-edit-button">
                  <a href="<?php echo e(route('movie.edit', ['movie' => $movie])); ?>">
                    <span class="material-symbols-rounded">
                      edit_note
                    </span>
                  </a>
                </div>
                <div class="movie-delete-button">
                  
                  <a type="submit" href="<?php echo e(route('movie.delete', ['movie' => $movie])); ?>">
                    <span class="material-symbols-rounded">
                      delete_forever
                    </span>
                  </a>
                  
                </div>
                <div class="movie-seen">
                  <?php if($movie->seen): ?>
                    <a class="badge bg-success" href="<?php echo e(route('movie.unsee', ['movie' => $movie])); ?>">Visto</a>
                  <?php else: ?>
                    <a class="badge bg-danger" href="<?php echo e(route('movie.see', ['movie' => $movie])); ?>">Da vedere</a>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          </div>
        </div>

          
           
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gabry\Lavoro\Web\Progetti\Filmi\filmi\resources\views/index.blade.php ENDPATH**/ ?>